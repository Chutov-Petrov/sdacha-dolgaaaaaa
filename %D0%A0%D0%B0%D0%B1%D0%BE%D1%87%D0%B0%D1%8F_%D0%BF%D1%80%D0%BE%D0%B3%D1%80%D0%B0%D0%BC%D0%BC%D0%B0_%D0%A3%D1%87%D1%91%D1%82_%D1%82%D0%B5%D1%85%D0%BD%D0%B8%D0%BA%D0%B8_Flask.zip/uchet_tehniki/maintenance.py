from pathlib import Path
import sqlite3

DB_PATH = Path(__file__).resolve().parent / "equipment.db"


def main():
    if not DB_PATH.exists():
        print("База данных не найдена. Сначала запустите app.py.")
        return
    with sqlite3.connect(DB_PATH) as db:
        integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
        total = db.execute("SELECT COUNT(*) FROM equipment").fetchone()[0]
        duplicates = db.execute("""
            SELECT COUNT(*) FROM (
                SELECT inventory_number FROM equipment
                GROUP BY inventory_number HAVING COUNT(*) > 1
            )
        """).fetchone()[0]
    print("Проверка базы данных")
    print(f"Целостность SQLite: {integrity}")
    print(f"Количество записей: {total}")
    print(f"Групп дублирующихся инвентарных номеров: {duplicates}")


if __name__ == "__main__":
    main()
