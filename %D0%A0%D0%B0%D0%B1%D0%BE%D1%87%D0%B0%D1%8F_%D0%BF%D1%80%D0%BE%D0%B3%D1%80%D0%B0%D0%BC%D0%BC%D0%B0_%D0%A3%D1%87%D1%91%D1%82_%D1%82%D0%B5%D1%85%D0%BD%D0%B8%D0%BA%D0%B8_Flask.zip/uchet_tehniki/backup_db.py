from pathlib import Path
from datetime import datetime
import sqlite3

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "equipment.db"
BACKUP_DIR = BASE_DIR / "backups"


def main():
    if not DB_PATH.exists():
        print("База данных ещё не создана. Сначала запустите app.py.")
        return
    BACKUP_DIR.mkdir(exist_ok=True)
    target = BACKUP_DIR / f"equipment_{datetime.now():%Y%m%d_%H%M%S}.db"
    with sqlite3.connect(DB_PATH) as source, sqlite3.connect(target) as destination:
        source.backup(destination)
    print(f"Резервная копия создана: {target}")


if __name__ == "__main__":
    main()
