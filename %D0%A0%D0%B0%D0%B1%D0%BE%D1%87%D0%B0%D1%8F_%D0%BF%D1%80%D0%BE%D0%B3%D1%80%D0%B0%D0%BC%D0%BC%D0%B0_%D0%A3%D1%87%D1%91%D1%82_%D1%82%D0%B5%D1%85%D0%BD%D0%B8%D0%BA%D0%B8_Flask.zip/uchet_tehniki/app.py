from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "equipment.db"


def get_db_connection():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def init_db():
    with get_db_connection() as connection:
        connection.execute("""
            CREATE TABLE IF NOT EXISTS equipment (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                inventory_number TEXT NOT NULL UNIQUE,
                serial_number TEXT DEFAULT '',
                room TEXT DEFAULT '',
                responsible_person TEXT DEFAULT '',
                status TEXT NOT NULL DEFAULT 'Исправно',
                notes TEXT DEFAULT ''
            )
        """)
        count = connection.execute("SELECT COUNT(*) FROM equipment").fetchone()[0]
        if count == 0:
            connection.executemany("""
                INSERT INTO equipment
                (name, inventory_number, serial_number, room, responsible_person, status, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, [
                ("Компьютер", "INV-0001", "SN-PC-001", "Кабинет 101", "Иванов И.И.", "Исправно", "Пример записи"),
                ("Монитор", "INV-0002", "SN-MON-002", "Кабинет 101", "Иванов И.И.", "Исправно", ""),
                ("Принтер", "INV-0003", "SN-PR-003", "Кабинет 205", "Петрова А.А.", "Требует ремонта", "Проверить подачу бумаги"),
            ])


@app.route("/")
def index():
    search = request.args.get("search", "").strip()
    room = request.args.get("room", "").strip()
    status = request.args.get("status", "").strip()

    query = "SELECT * FROM equipment WHERE 1=1"
    params = []

    if search:
        query += " AND (name LIKE ? OR inventory_number LIKE ? OR serial_number LIKE ?)"
        like = f"%{search}%"
        params.extend([like, like, like])
    if room:
        query += " AND room = ?"
        params.append(room)
    if status:
        query += " AND status = ?"
        params.append(status)

    query += " ORDER BY id DESC"

    with get_db_connection() as connection:
        equipment = connection.execute(query, params).fetchall()
        rooms = connection.execute(
            "SELECT DISTINCT room FROM equipment WHERE room <> '' ORDER BY room"
        ).fetchall()
        total = connection.execute("SELECT COUNT(*) FROM equipment").fetchone()[0]
        working = connection.execute(
            "SELECT COUNT(*) FROM equipment WHERE status = 'Исправно'"
        ).fetchone()[0]
        repair = connection.execute(
            "SELECT COUNT(*) FROM equipment WHERE status = 'Требует ремонта'"
        ).fetchone()[0]

    return render_template(
        "index.html", equipment=equipment, rooms=rooms, search=search,
        selected_room=room, selected_status=status, total=total,
        working=working, repair=repair
    )


@app.route("/add", methods=["GET", "POST"])
def add_equipment():
    if request.method == "POST":
        data = read_form()
        if not data["name"] or not data["inventory_number"]:
            flash("Заполните название и инвентарный номер.", "error")
            return render_template("form.html", item=data, page_title="Добавить оборудование")

        try:
            with get_db_connection() as connection:
                connection.execute("""
                    INSERT INTO equipment
                    (name, inventory_number, serial_number, room, responsible_person, status, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, tuple(data.values()))
            flash("Оборудование добавлено.", "success")
            return redirect(url_for("index"))
        except sqlite3.IntegrityError:
            flash("Такой инвентарный номер уже существует.", "error")
            return render_template("form.html", item=data, page_title="Добавить оборудование")

    return render_template("form.html", item={}, page_title="Добавить оборудование")


@app.route("/edit/<int:item_id>", methods=["GET", "POST"])
def edit_equipment(item_id):
    with get_db_connection() as connection:
        item = connection.execute("SELECT * FROM equipment WHERE id = ?", (item_id,)).fetchone()
    if item is None:
        flash("Запись не найдена.", "error")
        return redirect(url_for("index"))

    if request.method == "POST":
        data = read_form()
        if not data["name"] or not data["inventory_number"]:
            flash("Заполните название и инвентарный номер.", "error")
            return render_template("form.html", item=data, page_title="Редактировать оборудование")

        try:
            with get_db_connection() as connection:
                connection.execute("""
                    UPDATE equipment
                    SET name = ?, inventory_number = ?, serial_number = ?, room = ?,
                        responsible_person = ?, status = ?, notes = ?
                    WHERE id = ?
                """, (*tuple(data.values()), item_id))
            flash("Изменения сохранены.", "success")
            return redirect(url_for("index"))
        except sqlite3.IntegrityError:
            flash("Такой инвентарный номер уже существует у другой записи.", "error")
            return render_template("form.html", item=data, page_title="Редактировать оборудование")

    return render_template("form.html", item=dict(item), page_title="Редактировать оборудование")


@app.route("/delete/<int:item_id>", methods=["POST"])
def delete_equipment(item_id):
    with get_db_connection() as connection:
        connection.execute("DELETE FROM equipment WHERE id = ?", (item_id,))
    flash("Запись удалена.", "success")
    return redirect(url_for("index"))


def read_form():
    return {
        "name": request.form.get("name", "").strip(),
        "inventory_number": request.form.get("inventory_number", "").strip(),
        "serial_number": request.form.get("serial_number", "").strip(),
        "room": request.form.get("room", "").strip(),
        "responsible_person": request.form.get("responsible_person", "").strip(),
        "status": request.form.get("status", "Исправно").strip(),
        "notes": request.form.get("notes", "").strip(),
    }


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
